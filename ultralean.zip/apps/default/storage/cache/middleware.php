<?php return array (
  'AdminAuth' => 'App\\Middleware\\AdminAuth',
);